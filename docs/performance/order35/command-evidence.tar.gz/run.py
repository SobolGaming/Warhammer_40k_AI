import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('name')
p.add_argument('deadline', type=float)
p.add_argument('command')
p.add_argument('--cwd', default=os.getcwd())
a = p.parse_args()
root = Path('/private/tmp/order35-evidence')
start = time.monotonic()
stamp = datetime.datetime.now(datetime.UTC).isoformat()
log = root / f'{a.name}.log'
meta = root / f'{a.name}.json'
if log.exists() or meta.exists():
    raise SystemExit('Use a unique command name; existing evidence must be preserved')
env = dict(os.environ)
env.update(CI='1', GIT_TERMINAL_PROMPT='0', GH_PROMPT_DISABLED='1', GH_PAGER='cat', PAGER='cat', PYTHONUNBUFFERED='1')
record = dict(name=a.name, command=a.command, cwd=a.cwd, start_utc=stamp, deadline_seconds=a.deadline, log=str(log), next_action='consume terminal result and advance')
with log.open('w') as output:
    proc = subprocess.Popen(['/bin/zsh', '-f', '-e', '-c', a.command], cwd=a.cwd, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    record.update(pid=proc.pid, outcome='running')
    meta.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k != 'command'}), flush=True)
    progress = start
    timed_out = False
    while proc.poll() is None:
        now = time.monotonic()
        if now - start >= a.deadline:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            break
        if now - progress >= 20:
            print(json.dumps(dict(name=a.name, elapsed_seconds=round(now-start,1), log_bytes=log.stat().st_size, last_output=log.read_text(errors='replace')[-1800:])), flush=True)
            progress = now
        time.sleep(0.2)
    children = subprocess.run(['ps','-axo','pid=,pgid=,stat=,etime=,command='],capture_output=True,text=True,check=True).stdout
    remaining = [line for line in children.splitlines() if len(line.split()) > 1 and line.split()[1] == str(proc.pid)]
    if remaining:
        record['remaining_processes_before_recovery'] = remaining
        os.killpg(proc.pid, signal.SIGKILL)
    record.update(exit_status=proc.returncode, elapsed_seconds=round(time.monotonic()-start,3), outcome='timeout' if timed_out else 'orphan_processes' if remaining else 'success' if proc.returncode == 0 else 'nonzero')
    meta.write_text(json.dumps(record,indent=2)+'\n')
print(log.read_text(errors='replace')[-22000:], flush=True)
print(json.dumps({k:v for k,v in record.items() if k != 'command'}), flush=True)
raise SystemExit(124 if timed_out else 125 if remaining else proc.returncode)
