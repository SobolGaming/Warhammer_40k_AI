import json
from pathlib import Path
import shutil
from scripts import check_rapid_ingress_performance as gate

root = Path('/private/tmp/order35-evidence')
comparison = Path('/private/tmp/r35-001-performance-check')
destination = comparison / 'docs/performance/order35'
destination.mkdir(parents=True, exist_ok=True)
shutil.copyfile(root/'r35-001-base-timing.json', destination/'base.json')
shutil.copyfile(root/'r35-001-head-timing.json', destination/'head.json')
shutil.copyfile('docs/performance/order35/budgets.json', destination/'budgets.json')
gate.ROOT = comparison
gate.main()
base = json.loads((root/'r35-001-base-restore.json').read_text())
head = json.loads((root/'r35-001-head-restore.json').read_text())
for key in ('hashes','platform','python','timing_boundary'):
    assert base[key] == head[key], key
assert len(base['samples']) == len(head['samples']) == 14
for row in base['samples']:
    assert row['outcome'] == ('Pending Rapid Ingress target is ineligible: insufficient_command_points.' if row['discounted'] else 'restored')
assert all(row['outcome'] == 'restored' for row in head['samples'])
print('Identical-input restoration comparison passed; discounted base failures are not a correctness or performance oracle.')
