import argparse
import hashlib
import json
from pathlib import Path
import platform
import statistics
import subprocess
import time

from tests.rapid_ingress_helpers import ingress_session, reach_ingress_window
from warhammer40k_core.engine.lifecycle import GameLifecycle
from warhammer40k_core.engine.phase import GameLifecycleError

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
rows = []
for discounted in (False, True):
    session = ingress_session(automatic_discount=discounted)
    state = session.lifecycle.state
    assert state is not None
    if discounted:
        state.spend_command_points(player_id='player-b', amount=state.command_point_total('player-b'), source_id='test:r35-001:benchmark')
    reach_ingress_window(session)
    payload = json.loads(json.dumps(session.lifecycle.to_payload()))
    for sample in range(7):
        start = time.perf_counter()
        try:
            restored = GameLifecycle.from_payload(payload)
        except GameLifecycleError as error:
            outcome = str(error)
        else:
            outcome = 'restored'
        rows.append(dict(discounted=discounted, sample=sample, seconds=time.perf_counter()-start, outcome=outcome))
report = dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), runtime_diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--','src'])).hexdigest(), platform=platform.platform(), python=platform.python_version(), timing_boundary='GameLifecycle.from_payload only; prepared JSON checkpoint; one process, no test workers; seven repetitions per checkpoint', samples=rows, full_game_certified=False)
report['hashes'] = {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ('uv.lock','tests/rapid_ingress_helpers.py','tests/core_stratagem_helpers.py',__file__)}
report['summaries'] = {str(d):dict(mean=statistics.mean(r['seconds'] for r in rows if r['discounted']==d), max=max(r['seconds'] for r in rows if r['discounted']==d)) for d in (False, True)}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['summaries']))
