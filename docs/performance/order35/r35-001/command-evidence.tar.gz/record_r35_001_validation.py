import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('/private/tmp/order35-evidence')
destination = Path('docs/performance/order35/r35-001')
destination.mkdir(parents=True, exist_ok=True)
commands = []
for path in sorted(root.glob('r35-001-*.json')):
    data = json.loads(path.read_text())
    if 'command' in data:
        assert data['outcome'] != 'running', path
        commands.append(data)
for name in ('quality', 'coverage-recovery', 'coverage-total', 'types-gate', 'static-gates', 'contract-client', 'performance-check'):
    record = next(row for row in commands if row['name'] == 'r35-001-' + name)
    assert record['exit_status'] == 0, record
behavior = next(row for row in commands if row['name'] == 'r35-001-behavior')
assert behavior['exit_status'] == 1
suite = ET.parse(root/'r35-001-behavior.xml').getroot().find('testsuite')
assert suite is not None and suite.attrib['tests'] == '6982'
assert suite.attrib['errors'] == suite.attrib['failures'] == '0'
commands.sort(key=lambda row: row['start_utc'])
for name in ('base-timing', 'head-timing', 'base-restore', 'head-restore'):
    shutil.copyfile(root/f'r35-001-{name}.json', destination/f'{name}.json')
identities = subprocess.check_output(['git','rev-parse','031bdd5e59b3ce46ef5bcc5f03e25d685517402a^{tree}','HEAD:src','HEAD:tests','HEAD:scripts','HEAD:contracts'], text=True).splitlines()
report = dict(repair_request_utc='2026-09-10T12:05:24.633Z', evidence_recorded_utc=datetime.datetime.now(datetime.UTC).isoformat(), tested_commit='031bdd5e59b3ce46ef5bcc5f03e25d685517402a', trees=dict(zip(('tested','src','tests','scripts','contracts'), identities, strict=True)), commands=commands, full_game_certified=False, independent_approval=False)
report['coverage_recovery'] = dict(original_pytest_exit=1, behavioral_tests=6982, errors=0, failures=0, reason="Pytest coverage reporter could not open .coverage; separate coverage reports on the same saved database passed without repeating tests.", database_integrity='ok', measured_files=2499, arc_rows=451916, database_sha256=hashlib.sha256((root/'r35-001.coverage').read_bytes()).hexdigest())
(destination/'validation.json').write_text(json.dumps(report, indent=2)+'\n')
files = sorted(path for path in root.glob('r35-001-*') if path.suffix in {'.json','.log','.xml'})
files += [root/'run.py', root/'measure_r35_001_restore.py', root/'check_r35_001_performance.py', root/'r35-001.coverage', Path(__file__)]
with tarfile.open(destination/'command-evidence.tar.gz', 'w:gz') as archive:
    for path in files:
        archive.add(path, arcname=path.name)
print(json.dumps(dict(commands=len(commands), archive_files=len(files), trees=report['trees'])))
